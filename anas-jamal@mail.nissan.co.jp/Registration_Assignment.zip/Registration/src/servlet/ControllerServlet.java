package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/control")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pout=response.getWriter();
//		RequestDispatcher rd=request.getRequestDispatcher("serv2");
		
		boolean set=false;
		String FName=request.getParameter("FName");
		String LName=request.getParameter("LName");
		String phone=request.getParameter("phone");
		String mail=request.getParameter("mail");
		
		RegBean regObj = new RegBean();
		regObj.setfName(FName);
		regObj.setlName(LName);
		regObj.setMail(mail);
		regObj.setPhon(phone);
		
		
		request.setAttribute("bean", regObj);
//		System.out.println("test1");
		try {
			set=regObj.register();
//			System.out.println("test2");
			if(set==true) {
				pout.println("Registered Succesfully!");
			}else
				pout.print("Registration Failed. E mail already taken");
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
//		regObj.print();
		
	}

}

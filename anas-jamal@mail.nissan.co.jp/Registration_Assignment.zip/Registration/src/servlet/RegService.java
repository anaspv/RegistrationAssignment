package servlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class RegService {
	
	private String fName,lName,mail,phon;
	boolean flag=false;
	public RegService(String fName, String lName,String mail,String phone) {
		this.fName=fName;
		this.lName=lName;
		this.mail=mail;
		this.phon=phone;
	}

public  boolean check() throws Exception {
		
	Class.forName("com.mysql.jdbc.Driver");
	
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/userreg?useSSL=false", "root", "12345678"); 
	Statement stmt=con.createStatement();
	ResultSet rs=stmt.executeQuery("select * from user");
	while(rs.next()) {
		if(rs.getString(4).equals(mail)) {
			flag=true;
		}
	}
	return flag;
	
}
	
public  void addUser() throws Exception {
		
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/userreg?useSSL=false", "root", "12345678"); 
		Statement stmt=con.createStatement();
		
		stmt.executeUpdate("insert into user values("+null+",'"+fName+"','"+lName+"','"+mail+"','"+phon+"')");
//		System.out.println("User Registered Succesfully");
	
	}
}

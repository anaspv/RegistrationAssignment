package servlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Connect {
	public static void main(String[] args) throws Exception {
		addUser();
	}
	
public static void addUser() throws Exception {
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/userreg?useSSL=false", "root", "12345678"); 
		Statement stmt=con.createStatement();
		
		stmt.executeUpdate("insert into user values("+null+",'jhg','kljkhj')");
		System.out.println("User Registered Succesfully");
	
	}

}

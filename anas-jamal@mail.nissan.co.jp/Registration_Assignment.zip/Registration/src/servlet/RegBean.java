package servlet;



public class RegBean {
	
	private String fName,lName,mail,phon;
	boolean flag;
	boolean set=false;

	public String getfName() {
		return fName;
	}


	public void setfName(String fName) {
		this.fName = fName;
	}


	public String getlName() {
		return lName;
	}


	public void setlName(String lName) {
		this.lName = lName;
	}


	public String getMail() {
		return mail;
	}


	public void setMail(String mail) {
		this.mail = mail;
	}


	public String getPhon() {
		return phon;
	}


	public void setPhon(String phon) {
		this.phon = phon;
	}


	boolean register() throws Exception {
		RegService register=new RegService(fName,lName,mail,phon);
//		System.out.println("Test2");
		flag=register.check();
		if(flag==false) {
		register.addUser();
		set=true;
		}
		return set;
			
	}
}
